<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Lead\StoreLeadRequest;
use App\Http\Requests\Lead\UpdateLeadRequest;
use App\Models\Lead;
use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Services\LeadService;

class LeadController extends Controller
{
    protected LeadService $service;

    public function __construct(LeadService $service)
    {
        $this->service = $service;
    }

    public function index(Request $request)
    {
        $filters = $request->only([
            'owner_id', 'status', 'start_date', 'end_date', 'type', 'source',
            'pipeline_stage_id', 'keyword', 'created_by', 'updated_by', 'has_opportunity',
        ]);

        $leads = $this->service->list($filters, (int) $request->input('per_page', 15));

        return Inertia::render('leads/index', ['leads' => $leads]);
    }

    public function create()
    {
        return Inertia::render('leads/create', $this->service->getFormOptions());
    }

    public function edit(Lead $lead)
    {
        $lead->load('owner', 'questions', 'opportunity');

        return Inertia::render('leads/edit', array_merge(
            ['lead' => $lead],
            $this->service->getFormOptions()
        ));
    }

    public function show(Lead $lead)
    {
        $lead->load('owner', 'questions', 'opportunity');

        return Inertia::render('leads/show', compact('lead'));
    }

    public function update(UpdateLeadRequest $request, Lead $lead)
    {
        $data = $request->validated();
        $data['owner_id'] = $data['owner_id'] ?? $lead->owner_id ?? $request->user()->id;

        $this->service->update($lead, $data);

        return redirect()
            ->route('leads.show', $lead->id)
            ->with('success', 'Lead updated.');
    }

    public function store(StoreLeadRequest $request)
    {
        $data = $request->validated();
        $data['owner_id'] = $data['owner_id'] ?? $request->user()->id;

        $lead = $this->service->create($data);

        return redirect()
            ->route('leads.show', $lead->id)
            ->with('success', 'Lead created.');
    }

    public function destroy(Lead $lead)
    {
        $this->authorize('delete', $lead);

        $this->service->delete($lead);

        return redirect()
            ->route('leads.index')
            ->with('success', 'Lead deleted.');
    }
}
