<?php

namespace App\Http\Controllers\Api\V1;

use App\Events\LeadMoved;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\PipelineService;
use App\Models\Lead;
use App\Models\PipelineStage;
use Illuminate\Http\JsonResponse;

class PipelineController extends Controller
{
    private PipelineService $service;


    public function __construct(PipelineService $service)
    {
        $this->service = $service;
    }


    /** Move a lead to another pipeline stage */
    public function move(Request $request, Lead $lead): JsonResponse
    {
        $data = $request->validate([
            'to_stage_key' => 'required|string|exists:pipeline_stages,key',
        ]);

        $this->authorize('update', $lead);

        $updated = $this->service->moveLead(
            $lead->id,
            $data['to_stage_key'],
            $request->user()?->id
        );

        return response()->json([
            'ok' => true,
            'updated_lead' => $updated,
        ]);
    }
}
