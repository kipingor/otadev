<?php

namespace App\Services;

use App\Models\Lead;
use App\Models\Proposal;
use App\Services\AI\ProposalGeneratorService;

class ProposalGenerationService
{
    private ProposalGeneratorService $generator;

    public function __construct(ProposalGeneratorService $generator)
    {
        $this->generator = $generator;
    }

    /**
     * Generate a proposal for a lead by delegating to the AI ProposalGeneratorService.
     * Returns the created Proposal model instance (draft).
     */
    public function generateForLead(Lead $lead, array $options = []): Proposal
    {
        $opportunity = $lead->opportunity;

        // If opportunity exists, prefer generation from opportunity
        if ($opportunity) {
            $result = $this->generator->generateFromOpportunity($opportunity, $options);

            $proposal = Proposal::create([
                'lead_id' => $lead->id,
                'opportunity_id' => $opportunity->id,
                'content' => $result['draft'] ?? null,
                'status' => 'draft',
            ]);

            return $proposal;
        }

        // Fallback: produce a minimal draft
        $draft = "Proposal draft for lead: " . ($lead->title ?? 'Untitled');

        return Proposal::create([
            'lead_id' => $lead->id,
            'content' => $draft,
            'status' => 'draft',
        ]);
    }
}
