<?php

namespace App\Services;

use App\Events\LeadUpdated;
use App\Models\Lead;
use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class LeadService
{
    public function list(array $filters = [], int $perPage = 15): LengthAwarePaginator
    {
        $query = $this->getBaseQuery();

        if (!empty($filters['owner_id'])) {
            $query->where('owner_id', $filters['owner_id']);
        }
        if (!empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }
        if (!empty($filters['start_date']) && !empty($filters['end_date'])) {
            $query->whereBetween('created_at', [$filters['start_date'], $filters['end_date']]);
        }
        if (!empty($filters['type'])) {
            $query->where('type', $filters['type']);
        }
        if (!empty($filters['source'])) {
            $query->where('source', $filters['source']);
        }
        if (!empty($filters['pipeline_stage_id'])) {
            $query->where('pipeline_stage_id', $filters['pipeline_stage_id']);
        }
        if (!empty($filters['keyword'])) {
            $query->where('title', 'like', '%' . $filters['keyword'] . '%');
        }
        if (!empty($filters['created_by'])) {
            $query->where('created_by', $filters['created_by']);
        }
        if (!empty($filters['updated_by'])) {
            $query->where('updated_by', $filters['updated_by']);
        }
        if (isset($filters['has_opportunity'])) {
            if ($filters['has_opportunity']) {
                $query->whereNotNull('opportunity_id');
            } else {
                $query->whereNull('opportunity_id');
            }
        }

        return $query->orderByDesc('created_at')->paginate($perPage);
    }

    public function create(array $data): Lead
    {
        $lead = Lead::create($data);

        // Record activity for audit trails
        try {
            activity()
                ->performedOn($lead)
                ->causedBy(User::find($data['created_by'] ?? null))
                ->log('Lead created');
        } catch (\Throwable $e) {
            // ignore activity failures to avoid breaking creation
        }

        return $lead;
    }

    public function update(Lead $lead, array $data): Lead
    {
        $lead->update($data);

        try {
            activity()
                ->performedOn($lead)
                ->causedBy(User::find($data['updated_by'] ?? null))
                ->log('Lead updated');
        } catch (\Throwable $e) {
            // ignore activity failures
        }

        event(new LeadUpdated($lead));

        return $lead;
    }

    public function delete(Lead $lead): void
    {
        try {
            activity()
                ->performedOn($lead)
                ->causedBy(auth()->user() ?? null)
                ->log('Lead deleted');
        } catch (\Throwable $e) {
            // ignore
        }

        $lead->delete();
    }

    public function getFormOptions(): array
    {
        $users = User::orderBy('name')->get(['id', 'name']);
        return compact('users');
    }

    private function getBaseQuery()
    {
        return Lead::with('owner', 'questions', 'opportunity');
    }
}
