<?php

namespace App\Services;

use App\Models\Lead;

class AiOrchestrationService
{
    /**
     * Orchestrate follow-up questions for a lead using configured AI services.
     * Returns an array of follow-up questions (strings).
     */
    public function generateFollowUpQuestions(Lead $lead, array $options = []): array
    {
        // Placeholder orchestration — integrate with AI client/service layer
        $title = $lead->title ?? 'lead';
        $base = "Generate 3 concise follow-up questions for the lead: {$title}.";

        // If a dedicated AI client exists, call it. For now return simple defaults.
        return [
            "Can you confirm the primary decision maker for {$title}?",
            "What is the expected timeline for this engagement?",
            "Are there any budget constraints or preferred vendors?",
        ];
    }
}
