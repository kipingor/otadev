import DashboardController from './DashboardController'
import LeadController from './LeadController'
import OpportunityController from './OpportunityController'
import ProjectController from './ProjectController'
import SupplierController from './SupplierController'
import HRController from './HRController'
import AccountingController from './AccountingController'
import PipelineController from './PipelineController'
import ActivityController from './ActivityController'
import ConversationController from './ConversationController'
import VendorController from './VendorController'
import LeadDocumentController from './LeadDocumentController'

const Web = {
    DashboardController: Object.assign(DashboardController, DashboardController),
    LeadController: Object.assign(LeadController, LeadController),
    OpportunityController: Object.assign(OpportunityController, OpportunityController),
    ProjectController: Object.assign(ProjectController, ProjectController),
    SupplierController: Object.assign(SupplierController, SupplierController),
    HRController: Object.assign(HRController, HRController),
    AccountingController: Object.assign(AccountingController, AccountingController),
    PipelineController: Object.assign(PipelineController, PipelineController),
    ActivityController: Object.assign(ActivityController, ActivityController),
    ConversationController: Object.assign(ConversationController, ConversationController),
    VendorController: Object.assign(VendorController, VendorController),
    LeadDocumentController: Object.assign(LeadDocumentController, LeadDocumentController),
}

export default Web