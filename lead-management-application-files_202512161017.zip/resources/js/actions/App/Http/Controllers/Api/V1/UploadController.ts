import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\UploadController::uploadLeadDocument
* @see app/Http/Controllers/Api/V1/UploadController.php:15
* @route '/api/v1/upload'
*/
export const uploadLeadDocument = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadLeadDocument.url(options),
    method: 'post',
})

uploadLeadDocument.definition = {
    methods: ["post"],
    url: '/api/v1/upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\UploadController::uploadLeadDocument
* @see app/Http/Controllers/Api/V1/UploadController.php:15
* @route '/api/v1/upload'
*/
uploadLeadDocument.url = (options?: RouteQueryOptions) => {
    return uploadLeadDocument.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\UploadController::uploadLeadDocument
* @see app/Http/Controllers/Api/V1/UploadController.php:15
* @route '/api/v1/upload'
*/
uploadLeadDocument.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadLeadDocument.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\UploadController::uploadLeadDocument
* @see app/Http/Controllers/Api/V1/UploadController.php:15
* @route '/api/v1/upload'
*/
const uploadLeadDocumentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadLeadDocument.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\UploadController::uploadLeadDocument
* @see app/Http/Controllers/Api/V1/UploadController.php:15
* @route '/api/v1/upload'
*/
uploadLeadDocumentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadLeadDocument.url(options),
    method: 'post',
})

uploadLeadDocument.form = uploadLeadDocumentForm

const UploadController = { uploadLeadDocument }

export default UploadController