import PipelineController from './PipelineController'
import LeadController from './LeadController'
import LeadDocumentController from './LeadDocumentController'
import LeadQuestionController from './LeadQuestionController'
import TaskController from './TaskController'
import UploadController from './UploadController'

const V1 = {
    PipelineController: Object.assign(PipelineController, PipelineController),
    LeadController: Object.assign(LeadController, LeadController),
    LeadDocumentController: Object.assign(LeadDocumentController, LeadDocumentController),
    LeadQuestionController: Object.assign(LeadQuestionController, LeadQuestionController),
    TaskController: Object.assign(TaskController, TaskController),
    UploadController: Object.assign(UploadController, UploadController),
}

export default V1