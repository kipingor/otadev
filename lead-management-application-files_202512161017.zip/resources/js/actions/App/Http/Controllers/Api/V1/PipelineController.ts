import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/pipelines',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::store
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/pipelines',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::store
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::store
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::store
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::store
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::update
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{pipeline}'
*/
export const update = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/api/v1/pipelines/{pipeline}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::update
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{pipeline}'
*/
update.url = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pipeline: args }
    }

    if (Array.isArray(args)) {
        args = {
            pipeline: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        pipeline: args.pipeline,
    }

    return update.definition.url
            .replace('{pipeline}', parsedArgs.pipeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::update
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{pipeline}'
*/
update.patch = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::update
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{pipeline}'
*/
const updateForm = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::update
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{pipeline}'
*/
updateForm.patch = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::destroy
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{pipeline}'
*/
export const destroy = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/v1/pipelines/{pipeline}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::destroy
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{pipeline}'
*/
destroy.url = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pipeline: args }
    }

    if (Array.isArray(args)) {
        args = {
            pipeline: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        pipeline: args.pipeline,
    }

    return destroy.definition.url
            .replace('{pipeline}', parsedArgs.pipeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::destroy
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{pipeline}'
*/
destroy.delete = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::destroy
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{pipeline}'
*/
const destroyForm = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::destroy
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{pipeline}'
*/
destroyForm.delete = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::move
* @see app/Http/Controllers/Api/V1/PipelineController.php:25
* @route '/api/v1/leads/{lead}/move'
*/
export const move = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: move.url(args, options),
    method: 'put',
})

move.definition = {
    methods: ["put"],
    url: '/api/v1/leads/{lead}/move',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::move
* @see app/Http/Controllers/Api/V1/PipelineController.php:25
* @route '/api/v1/leads/{lead}/move'
*/
move.url = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lead: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { lead: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            lead: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        lead: typeof args.lead === 'object'
        ? args.lead.id
        : args.lead,
    }

    return move.definition.url
            .replace('{lead}', parsedArgs.lead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::move
* @see app/Http/Controllers/Api/V1/PipelineController.php:25
* @route '/api/v1/leads/{lead}/move'
*/
move.put = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: move.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::move
* @see app/Http/Controllers/Api/V1/PipelineController.php:25
* @route '/api/v1/leads/{lead}/move'
*/
const moveForm = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: move.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::move
* @see app/Http/Controllers/Api/V1/PipelineController.php:25
* @route '/api/v1/leads/{lead}/move'
*/
moveForm.put = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: move.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

move.form = moveForm

const PipelineController = { index, store, update, destroy, move }

export default PipelineController