import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::store
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:21
* @route '/api/v1/leads/{lead}/documents'
*/
export const store = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/leads/{lead}/documents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::store
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:21
* @route '/api/v1/leads/{lead}/documents'
*/
store.url = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lead: args }
    }

    if (Array.isArray(args)) {
        args = {
            lead: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        lead: args.lead,
    }

    return store.definition.url
            .replace('{lead}', parsedArgs.lead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::store
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:21
* @route '/api/v1/leads/{lead}/documents'
*/
store.post = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::store
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:21
* @route '/api/v1/leads/{lead}/documents'
*/
const storeForm = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::store
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:21
* @route '/api/v1/leads/{lead}/documents'
*/
storeForm.post = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::destroy
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:49
* @route '/api/v1/leads/{lead}/documents/{document}'
*/
export const destroy = (args: { lead: string | number, document: number | { id: number } } | [lead: string | number, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/v1/leads/{lead}/documents/{document}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::destroy
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:49
* @route '/api/v1/leads/{lead}/documents/{document}'
*/
destroy.url = (args: { lead: string | number, document: number | { id: number } } | [lead: string | number, document: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            lead: args[0],
            document: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        lead: args.lead,
        document: typeof args.document === 'object'
        ? args.document.id
        : args.document,
    }

    return destroy.definition.url
            .replace('{lead}', parsedArgs.lead.toString())
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::destroy
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:49
* @route '/api/v1/leads/{lead}/documents/{document}'
*/
destroy.delete = (args: { lead: string | number, document: number | { id: number } } | [lead: string | number, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::destroy
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:49
* @route '/api/v1/leads/{lead}/documents/{document}'
*/
const destroyForm = (args: { lead: string | number, document: number | { id: number } } | [lead: string | number, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::destroy
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:49
* @route '/api/v1/leads/{lead}/documents/{document}'
*/
destroyForm.delete = (args: { lead: string | number, document: number | { id: number } } | [lead: string | number, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const LeadDocumentController = { store, destroy }

export default LeadDocumentController