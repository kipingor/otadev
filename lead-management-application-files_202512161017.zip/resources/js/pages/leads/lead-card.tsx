import { Button } from '@/components/ui/button';
import {
    Card,
    CardContent,
    CardFooter,
    CardHeader,
    CardTitle,
} from '@/components/ui/card';
import { Link } from '@inertiajs/react';

export default function LeadCard({ lead }: { lead: any }) {
    const formatDate = (timestamp: string) => {
        const date = new Date(timestamp);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
        });
    };
    return (
        <Card className="border-0 bg-linear-to-br from-card to-card/50 shadow-sm transition-shadow duration-300 hover:shadow-lg">
            <CardHeader className="pd-4">
                <CardTitle className="text-lg font-semibold">
                    {lead.title ?? 'Untitled'}
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-sm text-muted-foreground">{lead.type}</p>
                <p className="mt-2 line-clamp-3 text-sm">{lead.description}</p>
            </CardContent>
            <CardFooter className="flex items-center justify-between pt-2">
                <Button
                    variant="ghost"
                    size="sm"
                    asChild
                    className="h-auto p-0 text-xs"
                >
                    <Link href={`/leads/${lead.id}`} className="p-1">
                        View →
                    </Link>
                </Button>
                <span className="text-xs text-muted-foreground">
                    {formatDate(lead.created_at)}
                </span>
            </CardFooter>
        </Card>
    );
}
