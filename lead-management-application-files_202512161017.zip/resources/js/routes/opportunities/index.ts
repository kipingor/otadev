import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\OpportunityController::index
* @see app/Http/Controllers/Web/OpportunityController.php:15
* @route '/opportunities'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/opportunities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\OpportunityController::index
* @see app/Http/Controllers/Web/OpportunityController.php:15
* @route '/opportunities'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\OpportunityController::index
* @see app/Http/Controllers/Web/OpportunityController.php:15
* @route '/opportunities'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::index
* @see app/Http/Controllers/Web/OpportunityController.php:15
* @route '/opportunities'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::index
* @see app/Http/Controllers/Web/OpportunityController.php:15
* @route '/opportunities'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::index
* @see app/Http/Controllers/Web/OpportunityController.php:15
* @route '/opportunities'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::index
* @see app/Http/Controllers/Web/OpportunityController.php:15
* @route '/opportunities'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Web\OpportunityController::create
* @see app/Http/Controllers/Web/OpportunityController.php:45
* @route '/opportunities/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/opportunities/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\OpportunityController::create
* @see app/Http/Controllers/Web/OpportunityController.php:45
* @route '/opportunities/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\OpportunityController::create
* @see app/Http/Controllers/Web/OpportunityController.php:45
* @route '/opportunities/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::create
* @see app/Http/Controllers/Web/OpportunityController.php:45
* @route '/opportunities/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::create
* @see app/Http/Controllers/Web/OpportunityController.php:45
* @route '/opportunities/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::create
* @see app/Http/Controllers/Web/OpportunityController.php:45
* @route '/opportunities/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::create
* @see app/Http/Controllers/Web/OpportunityController.php:45
* @route '/opportunities/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Web\OpportunityController::store
* @see app/Http/Controllers/Web/OpportunityController.php:68
* @route '/opportunities'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/opportunities',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\OpportunityController::store
* @see app/Http/Controllers/Web/OpportunityController.php:68
* @route '/opportunities'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\OpportunityController::store
* @see app/Http/Controllers/Web/OpportunityController.php:68
* @route '/opportunities'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::store
* @see app/Http/Controllers/Web/OpportunityController.php:68
* @route '/opportunities'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::store
* @see app/Http/Controllers/Web/OpportunityController.php:68
* @route '/opportunities'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Web\OpportunityController::show
* @see app/Http/Controllers/Web/OpportunityController.php:32
* @route '/opportunities/{opportunity}'
*/
export const show = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/opportunities/{opportunity}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\OpportunityController::show
* @see app/Http/Controllers/Web/OpportunityController.php:32
* @route '/opportunities/{opportunity}'
*/
show.url = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { opportunity: args }
    }

    if (Array.isArray(args)) {
        args = {
            opportunity: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        opportunity: args.opportunity,
    }

    return show.definition.url
            .replace('{opportunity}', parsedArgs.opportunity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\OpportunityController::show
* @see app/Http/Controllers/Web/OpportunityController.php:32
* @route '/opportunities/{opportunity}'
*/
show.get = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::show
* @see app/Http/Controllers/Web/OpportunityController.php:32
* @route '/opportunities/{opportunity}'
*/
show.head = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::show
* @see app/Http/Controllers/Web/OpportunityController.php:32
* @route '/opportunities/{opportunity}'
*/
const showForm = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::show
* @see app/Http/Controllers/Web/OpportunityController.php:32
* @route '/opportunities/{opportunity}'
*/
showForm.get = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::show
* @see app/Http/Controllers/Web/OpportunityController.php:32
* @route '/opportunities/{opportunity}'
*/
showForm.head = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Web\OpportunityController::edit
* @see app/Http/Controllers/Web/OpportunityController.php:52
* @route '/opportunities/{opportunity}/edit'
*/
export const edit = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/opportunities/{opportunity}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\OpportunityController::edit
* @see app/Http/Controllers/Web/OpportunityController.php:52
* @route '/opportunities/{opportunity}/edit'
*/
edit.url = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { opportunity: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { opportunity: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            opportunity: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        opportunity: typeof args.opportunity === 'object'
        ? args.opportunity.id
        : args.opportunity,
    }

    return edit.definition.url
            .replace('{opportunity}', parsedArgs.opportunity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\OpportunityController::edit
* @see app/Http/Controllers/Web/OpportunityController.php:52
* @route '/opportunities/{opportunity}/edit'
*/
edit.get = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::edit
* @see app/Http/Controllers/Web/OpportunityController.php:52
* @route '/opportunities/{opportunity}/edit'
*/
edit.head = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::edit
* @see app/Http/Controllers/Web/OpportunityController.php:52
* @route '/opportunities/{opportunity}/edit'
*/
const editForm = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::edit
* @see app/Http/Controllers/Web/OpportunityController.php:52
* @route '/opportunities/{opportunity}/edit'
*/
editForm.get = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::edit
* @see app/Http/Controllers/Web/OpportunityController.php:52
* @route '/opportunities/{opportunity}/edit'
*/
editForm.head = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Web\OpportunityController::update
* @see app/Http/Controllers/Web/OpportunityController.php:79
* @route '/opportunities/{opportunity}'
*/
export const update = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/opportunities/{opportunity}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Web\OpportunityController::update
* @see app/Http/Controllers/Web/OpportunityController.php:79
* @route '/opportunities/{opportunity}'
*/
update.url = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { opportunity: args }
    }

    if (Array.isArray(args)) {
        args = {
            opportunity: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        opportunity: args.opportunity,
    }

    return update.definition.url
            .replace('{opportunity}', parsedArgs.opportunity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\OpportunityController::update
* @see app/Http/Controllers/Web/OpportunityController.php:79
* @route '/opportunities/{opportunity}'
*/
update.put = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::update
* @see app/Http/Controllers/Web/OpportunityController.php:79
* @route '/opportunities/{opportunity}'
*/
update.patch = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::update
* @see app/Http/Controllers/Web/OpportunityController.php:79
* @route '/opportunities/{opportunity}'
*/
const updateForm = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::update
* @see app/Http/Controllers/Web/OpportunityController.php:79
* @route '/opportunities/{opportunity}'
*/
updateForm.put = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::update
* @see app/Http/Controllers/Web/OpportunityController.php:79
* @route '/opportunities/{opportunity}'
*/
updateForm.patch = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Web\OpportunityController::destroy
* @see app/Http/Controllers/Web/OpportunityController.php:92
* @route '/opportunities/{opportunity}'
*/
export const destroy = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/opportunities/{opportunity}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\OpportunityController::destroy
* @see app/Http/Controllers/Web/OpportunityController.php:92
* @route '/opportunities/{opportunity}'
*/
destroy.url = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { opportunity: args }
    }

    if (Array.isArray(args)) {
        args = {
            opportunity: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        opportunity: args.opportunity,
    }

    return destroy.definition.url
            .replace('{opportunity}', parsedArgs.opportunity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\OpportunityController::destroy
* @see app/Http/Controllers/Web/OpportunityController.php:92
* @route '/opportunities/{opportunity}'
*/
destroy.delete = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::destroy
* @see app/Http/Controllers/Web/OpportunityController.php:92
* @route '/opportunities/{opportunity}'
*/
const destroyForm = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\OpportunityController::destroy
* @see app/Http/Controllers/Web/OpportunityController.php:92
* @route '/opportunities/{opportunity}'
*/
destroyForm.delete = (args: { opportunity: string | number } | [opportunity: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const opportunities = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default opportunities