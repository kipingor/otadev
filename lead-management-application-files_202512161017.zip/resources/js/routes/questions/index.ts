import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::index
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:17
* @route '/api/v1/questions'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/questions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::index
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:17
* @route '/api/v1/questions'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::index
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:17
* @route '/api/v1/questions'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::index
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:17
* @route '/api/v1/questions'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::index
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:17
* @route '/api/v1/questions'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::index
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:17
* @route '/api/v1/questions'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::index
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:17
* @route '/api/v1/questions'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::store
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:27
* @route '/api/v1/questions'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/questions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::store
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:27
* @route '/api/v1/questions'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::store
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:27
* @route '/api/v1/questions'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::store
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:27
* @route '/api/v1/questions'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::store
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:27
* @route '/api/v1/questions'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::show
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:0
* @route '/api/v1/questions/{question}'
*/
export const show = (args: { question: string | number } | [question: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/questions/{question}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::show
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:0
* @route '/api/v1/questions/{question}'
*/
show.url = (args: { question: string | number } | [question: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

    if (Array.isArray(args)) {
        args = {
            question: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        question: args.question,
    }

    return show.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::show
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:0
* @route '/api/v1/questions/{question}'
*/
show.get = (args: { question: string | number } | [question: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::show
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:0
* @route '/api/v1/questions/{question}'
*/
show.head = (args: { question: string | number } | [question: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::show
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:0
* @route '/api/v1/questions/{question}'
*/
const showForm = (args: { question: string | number } | [question: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::show
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:0
* @route '/api/v1/questions/{question}'
*/
showForm.get = (args: { question: string | number } | [question: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::show
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:0
* @route '/api/v1/questions/{question}'
*/
showForm.head = (args: { question: string | number } | [question: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::update
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:51
* @route '/api/v1/questions/{question}'
*/
export const update = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/v1/questions/{question}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::update
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:51
* @route '/api/v1/questions/{question}'
*/
update.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { question: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            question: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        question: typeof args.question === 'object'
        ? args.question.id
        : args.question,
    }

    return update.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::update
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:51
* @route '/api/v1/questions/{question}'
*/
update.put = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::update
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:51
* @route '/api/v1/questions/{question}'
*/
update.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::update
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:51
* @route '/api/v1/questions/{question}'
*/
const updateForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::update
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:51
* @route '/api/v1/questions/{question}'
*/
updateForm.put = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::update
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:51
* @route '/api/v1/questions/{question}'
*/
updateForm.patch = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::destroy
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:76
* @route '/api/v1/questions/{question}'
*/
export const destroy = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/v1/questions/{question}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::destroy
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:76
* @route '/api/v1/questions/{question}'
*/
destroy.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { question: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            question: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        question: typeof args.question === 'object'
        ? args.question.id
        : args.question,
    }

    return destroy.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::destroy
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:76
* @route '/api/v1/questions/{question}'
*/
destroy.delete = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::destroy
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:76
* @route '/api/v1/questions/{question}'
*/
const destroyForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadQuestionController::destroy
* @see app/Http/Controllers/Api/V1/LeadQuestionController.php:76
* @route '/api/v1/questions/{question}'
*/
destroyForm.delete = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const questions = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default questions