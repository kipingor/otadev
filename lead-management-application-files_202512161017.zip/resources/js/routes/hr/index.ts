import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\HRController::index
* @see app/Http/Controllers/Web/HRController.php:15
* @route '/hr'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/hr',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\HRController::index
* @see app/Http/Controllers/Web/HRController.php:15
* @route '/hr'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\HRController::index
* @see app/Http/Controllers/Web/HRController.php:15
* @route '/hr'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\HRController::index
* @see app/Http/Controllers/Web/HRController.php:15
* @route '/hr'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\HRController::index
* @see app/Http/Controllers/Web/HRController.php:15
* @route '/hr'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\HRController::index
* @see app/Http/Controllers/Web/HRController.php:15
* @route '/hr'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\HRController::index
* @see app/Http/Controllers/Web/HRController.php:15
* @route '/hr'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const hr = {
    index: Object.assign(index, index),
}

export default hr