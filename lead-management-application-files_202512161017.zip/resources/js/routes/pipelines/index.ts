import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/pipelines',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const pipelines = {
    index: Object.assign(index, index),
}

export default pipelines