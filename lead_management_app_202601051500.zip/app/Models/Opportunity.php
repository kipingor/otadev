<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Policies\OpportunityPolicy;
use Illuminate\Database\Eloquent\Attributes\UsePolicy;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

#[UsePolicy(OpportunityPolicy::class)]
class Opportunity extends Model
{
    use HasFactory, SoftDeletes;

    public const STAGES = [
        'prospect',
        'proposal',
        'negotiation',
        'won',
        'lost',
    ];

    protected $fillable = [
        'lead_id',
        'title',
        'summary',
        'estimated_value',
        'currency',
        'stage',
        'owner_id',
        'expected_close_date',
        'ai_suggestions',
    ];

    protected $casts = [
        'ai_suggestions' => 'array',
        'estimated_value' => 'decimal:2',
        'expected_close_date' => 'datetime:Y-m-d',
    ];

    public function lead()
    {
        return $this->belongsTo(Lead::class);
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function project()
    {
        return $this->hasOne(Project::class);
    }

    /**
     * Get the proposals for this opportunity.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function proposals()
    {
        return $this->hasMany(Proposal::class);
    }

    /**
     * Get the emails associated with this opportunity.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function emails()
    {
        return $this->hasMany(Email::class);
    }
}
