<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Gate;
use App\Models\User;
use App\Models\Opportunity;
use App\Models\Project;
use App\Models\Lead;
use App\Models\LeadQuestion;
use App\Models\LeadDocument;
use App\Models\Activity;
use App\Models\Conversation;
use App\Models\Milestone;
use App\Models\PipelineStage;
use App\Policies\UserPolicy;
use App\Policies\OpportunityPolicy;
use App\Policies\ProjectPolicy;
use App\Policies\LeadPolicy;
use App\Policies\ActivityPolicy;
use App\Policies\LeadDocumentPolicy;
use App\Policies\ConversationPolicy;
use App\Policies\LeadQuestionPolicy;
use App\Policies\MilestonePolicy;
use App\Policies\PipelineStagePolicy;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\URL;
use DateTime;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        if (!empty(config('services.openai.api_key'))) {
            $this->app->bind(
                \App\Services\AI\OpenAIClientInterface::class,
                \App\Services\AI\OpenAIClient::class
            );
        } else {
            $this->app->bind(
                \App\Services\AI\OpenAIClientInterface::class,
                \App\Services\AI\NullOpenAIClient::class
            );
        }
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Register model policies so `Gate::authorize('action', Model::class)` works
        Gate::policy(User::class, UserPolicy::class);
        Gate::policy(Opportunity::class, OpportunityPolicy::class);
        Gate::policy(Project::class, ProjectPolicy::class);
        Gate::policy(Lead::class, LeadPolicy::class);
        Gate::policy(PipelineStage::class, PipelineStagePolicy::class);
        Gate::policy(LeadQuestion::class, LeadQuestionPolicy::class);
        Gate::policy(LeadDocument::class, LeadDocumentPolicy::class);
        Gate::policy(Activity::class, ActivityPolicy::class);
        Gate::policy(Conversation::class, ConversationPolicy::class);
        Gate::policy(Milestone::class, MilestonePolicy::class);

        // Storage::disk('local')->buildTemporaryUrlsUsing(

        //     function (string $path, DateTime $expiration, array $options) {
        //         return URL::temporarySignedRoute(
        //             'files.download',
        //             $expiration,
        //             array_merge($options, ['path' => $path])
        //         );
        //     }

        // );
    }
}
