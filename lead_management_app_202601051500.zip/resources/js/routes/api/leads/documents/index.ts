import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::store
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:21
* @route '/api/v1/leads/{lead}/documents'
*/
export const store = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/leads/{lead}/documents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::store
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:21
* @route '/api/v1/leads/{lead}/documents'
*/
store.url = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lead: args }
    }

    if (Array.isArray(args)) {
        args = {
            lead: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        lead: args.lead,
    }

    return store.definition.url
            .replace('{lead}', parsedArgs.lead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::store
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:21
* @route '/api/v1/leads/{lead}/documents'
*/
store.post = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::store
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:21
* @route '/api/v1/leads/{lead}/documents'
*/
const storeForm = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::store
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:21
* @route '/api/v1/leads/{lead}/documents'
*/
storeForm.post = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::index
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:39
* @route '/api/v1/leads/{lead}/documents'
*/
export const index = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/leads/{lead}/documents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::index
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:39
* @route '/api/v1/leads/{lead}/documents'
*/
index.url = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lead: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { lead: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            lead: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        lead: typeof args.lead === 'object'
        ? args.lead.id
        : args.lead,
    }

    return index.definition.url
            .replace('{lead}', parsedArgs.lead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::index
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:39
* @route '/api/v1/leads/{lead}/documents'
*/
index.get = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::index
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:39
* @route '/api/v1/leads/{lead}/documents'
*/
index.head = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::index
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:39
* @route '/api/v1/leads/{lead}/documents'
*/
const indexForm = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::index
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:39
* @route '/api/v1/leads/{lead}/documents'
*/
indexForm.get = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\LeadDocumentController::index
* @see app/Http/Controllers/Api/V1/LeadDocumentController.php:39
* @route '/api/v1/leads/{lead}/documents'
*/
indexForm.head = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const documents = {
    store: Object.assign(store, store),
    index: Object.assign(index, index),
}

export default documents