import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\UploadController::upload
* @see app/Http/Controllers/Api/V1/UploadController.php:0
* @route '/api/v1/upload'
*/
export const upload = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

upload.definition = {
    methods: ["post"],
    url: '/api/v1/upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\UploadController::upload
* @see app/Http/Controllers/Api/V1/UploadController.php:0
* @route '/api/v1/upload'
*/
upload.url = (options?: RouteQueryOptions) => {
    return upload.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\UploadController::upload
* @see app/Http/Controllers/Api/V1/UploadController.php:0
* @route '/api/v1/upload'
*/
upload.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\UploadController::upload
* @see app/Http/Controllers/Api/V1/UploadController.php:0
* @route '/api/v1/upload'
*/
const uploadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: upload.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\UploadController::upload
* @see app/Http/Controllers/Api/V1/UploadController.php:0
* @route '/api/v1/upload'
*/
uploadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: upload.url(options),
    method: 'post',
})

upload.form = uploadForm

/**
* @see \App\Http\Controllers\Api\V1\UploadController::uploadLeadDocument
* @see app/Http/Controllers/Api/V1/UploadController.php:15
* @route '/api/v1/upload/lead-document'
*/
export const uploadLeadDocument = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadLeadDocument.url(options),
    method: 'post',
})

uploadLeadDocument.definition = {
    methods: ["post"],
    url: '/api/v1/upload/lead-document',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\UploadController::uploadLeadDocument
* @see app/Http/Controllers/Api/V1/UploadController.php:15
* @route '/api/v1/upload/lead-document'
*/
uploadLeadDocument.url = (options?: RouteQueryOptions) => {
    return uploadLeadDocument.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\UploadController::uploadLeadDocument
* @see app/Http/Controllers/Api/V1/UploadController.php:15
* @route '/api/v1/upload/lead-document'
*/
uploadLeadDocument.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadLeadDocument.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\UploadController::uploadLeadDocument
* @see app/Http/Controllers/Api/V1/UploadController.php:15
* @route '/api/v1/upload/lead-document'
*/
const uploadLeadDocumentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadLeadDocument.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\UploadController::uploadLeadDocument
* @see app/Http/Controllers/Api/V1/UploadController.php:15
* @route '/api/v1/upload/lead-document'
*/
uploadLeadDocumentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadLeadDocument.url(options),
    method: 'post',
})

uploadLeadDocument.form = uploadLeadDocumentForm

const UploadController = { upload, uploadLeadDocument }

export default UploadController