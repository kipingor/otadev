import LeadController from './LeadController'
import LeadDocumentController from './LeadDocumentController'
import LeadQuestionController from './LeadQuestionController'
import PipelineController from './PipelineController'
import OpportunityController from './OpportunityController'
import ProjectController from './ProjectController'
import TaskController from './TaskController'
import ProposalController from './ProposalController'
import AiController from './AiController'
import UploadController from './UploadController'
import DashboardController from './DashboardController'

const V1 = {
    LeadController: Object.assign(LeadController, LeadController),
    LeadDocumentController: Object.assign(LeadDocumentController, LeadDocumentController),
    LeadQuestionController: Object.assign(LeadQuestionController, LeadQuestionController),
    PipelineController: Object.assign(PipelineController, PipelineController),
    OpportunityController: Object.assign(OpportunityController, OpportunityController),
    ProjectController: Object.assign(ProjectController, ProjectController),
    TaskController: Object.assign(TaskController, TaskController),
    ProposalController: Object.assign(ProposalController, ProposalController),
    AiController: Object.assign(AiController, AiController),
    UploadController: Object.assign(UploadController, UploadController),
    DashboardController: Object.assign(DashboardController, DashboardController),
}

export default V1