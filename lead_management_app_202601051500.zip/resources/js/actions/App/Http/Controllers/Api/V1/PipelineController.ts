import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/pipelines',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::index
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::move
* @see app/Http/Controllers/Api/V1/PipelineController.php:19
* @route '/api/v1/leads/{lead}/move'
*/
export const move = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: move.url(args, options),
    method: 'put',
})

move.definition = {
    methods: ["put"],
    url: '/api/v1/leads/{lead}/move',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::move
* @see app/Http/Controllers/Api/V1/PipelineController.php:19
* @route '/api/v1/leads/{lead}/move'
*/
move.url = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lead: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { lead: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            lead: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        lead: typeof args.lead === 'object'
        ? args.lead.id
        : args.lead,
    }

    return move.definition.url
            .replace('{lead}', parsedArgs.lead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::move
* @see app/Http/Controllers/Api/V1/PipelineController.php:19
* @route '/api/v1/leads/{lead}/move'
*/
move.put = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: move.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::move
* @see app/Http/Controllers/Api/V1/PipelineController.php:19
* @route '/api/v1/leads/{lead}/move'
*/
const moveForm = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: move.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::move
* @see app/Http/Controllers/Api/V1/PipelineController.php:19
* @route '/api/v1/leads/{lead}/move'
*/
moveForm.put = (args: { lead: number | { id: number } } | [lead: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: move.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

move.form = moveForm

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::getLeads
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{stage}/leads'
*/
export const getLeads = (args: { stage: string | number } | [stage: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getLeads.url(args, options),
    method: 'get',
})

getLeads.definition = {
    methods: ["get","head"],
    url: '/api/v1/pipelines/{stage}/leads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::getLeads
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{stage}/leads'
*/
getLeads.url = (args: { stage: string | number } | [stage: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { stage: args }
    }

    if (Array.isArray(args)) {
        args = {
            stage: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        stage: args.stage,
    }

    return getLeads.definition.url
            .replace('{stage}', parsedArgs.stage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::getLeads
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{stage}/leads'
*/
getLeads.get = (args: { stage: string | number } | [stage: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getLeads.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::getLeads
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{stage}/leads'
*/
getLeads.head = (args: { stage: string | number } | [stage: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getLeads.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::getLeads
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{stage}/leads'
*/
const getLeadsForm = (args: { stage: string | number } | [stage: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getLeads.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::getLeads
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{stage}/leads'
*/
getLeadsForm.get = (args: { stage: string | number } | [stage: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getLeads.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\PipelineController::getLeads
* @see app/Http/Controllers/Api/V1/PipelineController.php:0
* @route '/api/v1/pipelines/{stage}/leads'
*/
getLeadsForm.head = (args: { stage: string | number } | [stage: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getLeads.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getLeads.form = getLeadsForm

const PipelineController = { index, move, getLeads }

export default PipelineController