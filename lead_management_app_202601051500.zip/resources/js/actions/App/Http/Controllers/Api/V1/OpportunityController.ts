import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::index
* @see app/Http/Controllers/Api/V1/OpportunityController.php:20
* @route '/api/v1/opportunities'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/opportunities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::index
* @see app/Http/Controllers/Api/V1/OpportunityController.php:20
* @route '/api/v1/opportunities'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::index
* @see app/Http/Controllers/Api/V1/OpportunityController.php:20
* @route '/api/v1/opportunities'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::index
* @see app/Http/Controllers/Api/V1/OpportunityController.php:20
* @route '/api/v1/opportunities'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::index
* @see app/Http/Controllers/Api/V1/OpportunityController.php:20
* @route '/api/v1/opportunities'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::index
* @see app/Http/Controllers/Api/V1/OpportunityController.php:20
* @route '/api/v1/opportunities'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::index
* @see app/Http/Controllers/Api/V1/OpportunityController.php:20
* @route '/api/v1/opportunities'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::store
* @see app/Http/Controllers/Api/V1/OpportunityController.php:38
* @route '/api/v1/opportunities'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/opportunities',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::store
* @see app/Http/Controllers/Api/V1/OpportunityController.php:38
* @route '/api/v1/opportunities'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::store
* @see app/Http/Controllers/Api/V1/OpportunityController.php:38
* @route '/api/v1/opportunities'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::store
* @see app/Http/Controllers/Api/V1/OpportunityController.php:38
* @route '/api/v1/opportunities'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::store
* @see app/Http/Controllers/Api/V1/OpportunityController.php:38
* @route '/api/v1/opportunities'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::show
* @see app/Http/Controllers/Api/V1/OpportunityController.php:64
* @route '/api/v1/opportunities/{opportunity}'
*/
export const show = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/opportunities/{opportunity}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::show
* @see app/Http/Controllers/Api/V1/OpportunityController.php:64
* @route '/api/v1/opportunities/{opportunity}'
*/
show.url = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { opportunity: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { opportunity: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            opportunity: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        opportunity: typeof args.opportunity === 'object'
        ? args.opportunity.id
        : args.opportunity,
    }

    return show.definition.url
            .replace('{opportunity}', parsedArgs.opportunity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::show
* @see app/Http/Controllers/Api/V1/OpportunityController.php:64
* @route '/api/v1/opportunities/{opportunity}'
*/
show.get = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::show
* @see app/Http/Controllers/Api/V1/OpportunityController.php:64
* @route '/api/v1/opportunities/{opportunity}'
*/
show.head = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::show
* @see app/Http/Controllers/Api/V1/OpportunityController.php:64
* @route '/api/v1/opportunities/{opportunity}'
*/
const showForm = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::show
* @see app/Http/Controllers/Api/V1/OpportunityController.php:64
* @route '/api/v1/opportunities/{opportunity}'
*/
showForm.get = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::show
* @see app/Http/Controllers/Api/V1/OpportunityController.php:64
* @route '/api/v1/opportunities/{opportunity}'
*/
showForm.head = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::update
* @see app/Http/Controllers/Api/V1/OpportunityController.php:79
* @route '/api/v1/opportunities/{opportunity}'
*/
export const update = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/v1/opportunities/{opportunity}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::update
* @see app/Http/Controllers/Api/V1/OpportunityController.php:79
* @route '/api/v1/opportunities/{opportunity}'
*/
update.url = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { opportunity: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { opportunity: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            opportunity: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        opportunity: typeof args.opportunity === 'object'
        ? args.opportunity.id
        : args.opportunity,
    }

    return update.definition.url
            .replace('{opportunity}', parsedArgs.opportunity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::update
* @see app/Http/Controllers/Api/V1/OpportunityController.php:79
* @route '/api/v1/opportunities/{opportunity}'
*/
update.put = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::update
* @see app/Http/Controllers/Api/V1/OpportunityController.php:79
* @route '/api/v1/opportunities/{opportunity}'
*/
update.patch = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::update
* @see app/Http/Controllers/Api/V1/OpportunityController.php:79
* @route '/api/v1/opportunities/{opportunity}'
*/
const updateForm = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::update
* @see app/Http/Controllers/Api/V1/OpportunityController.php:79
* @route '/api/v1/opportunities/{opportunity}'
*/
updateForm.put = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::update
* @see app/Http/Controllers/Api/V1/OpportunityController.php:79
* @route '/api/v1/opportunities/{opportunity}'
*/
updateForm.patch = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::destroy
* @see app/Http/Controllers/Api/V1/OpportunityController.php:104
* @route '/api/v1/opportunities/{opportunity}'
*/
export const destroy = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/v1/opportunities/{opportunity}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::destroy
* @see app/Http/Controllers/Api/V1/OpportunityController.php:104
* @route '/api/v1/opportunities/{opportunity}'
*/
destroy.url = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { opportunity: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { opportunity: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            opportunity: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        opportunity: typeof args.opportunity === 'object'
        ? args.opportunity.id
        : args.opportunity,
    }

    return destroy.definition.url
            .replace('{opportunity}', parsedArgs.opportunity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::destroy
* @see app/Http/Controllers/Api/V1/OpportunityController.php:104
* @route '/api/v1/opportunities/{opportunity}'
*/
destroy.delete = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::destroy
* @see app/Http/Controllers/Api/V1/OpportunityController.php:104
* @route '/api/v1/opportunities/{opportunity}'
*/
const destroyForm = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\OpportunityController::destroy
* @see app/Http/Controllers/Api/V1/OpportunityController.php:104
* @route '/api/v1/opportunities/{opportunity}'
*/
destroyForm.delete = (args: { opportunity: number | { id: number } } | [opportunity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const OpportunityController = { index, store, show, update, destroy }

export default OpportunityController