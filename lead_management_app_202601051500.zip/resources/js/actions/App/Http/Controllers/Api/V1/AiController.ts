import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\AiController::generateContent
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/generate'
*/
export const generateContent = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateContent.url(options),
    method: 'post',
})

generateContent.definition = {
    methods: ["post"],
    url: '/api/v1/ai/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiController::generateContent
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/generate'
*/
generateContent.url = (options?: RouteQueryOptions) => {
    return generateContent.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiController::generateContent
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/generate'
*/
generateContent.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateContent.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\AiController::generateContent
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/generate'
*/
const generateContentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generateContent.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\AiController::generateContent
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/generate'
*/
generateContentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generateContent.url(options),
    method: 'post',
})

generateContent.form = generateContentForm

/**
* @see \App\Http\Controllers\Api\V1\AiController::followUp
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/follow-up'
*/
export const followUp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: followUp.url(options),
    method: 'post',
})

followUp.definition = {
    methods: ["post"],
    url: '/api/v1/ai/follow-up',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiController::followUp
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/follow-up'
*/
followUp.url = (options?: RouteQueryOptions) => {
    return followUp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiController::followUp
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/follow-up'
*/
followUp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: followUp.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\AiController::followUp
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/follow-up'
*/
const followUpForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: followUp.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\AiController::followUp
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/follow-up'
*/
followUpForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: followUp.url(options),
    method: 'post',
})

followUp.form = followUpForm

/**
* @see \App\Http\Controllers\Api\V1\AiController::extractDocument
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/extract-document'
*/
export const extractDocument = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: extractDocument.url(options),
    method: 'post',
})

extractDocument.definition = {
    methods: ["post"],
    url: '/api/v1/ai/extract-document',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiController::extractDocument
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/extract-document'
*/
extractDocument.url = (options?: RouteQueryOptions) => {
    return extractDocument.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiController::extractDocument
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/extract-document'
*/
extractDocument.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: extractDocument.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\AiController::extractDocument
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/extract-document'
*/
const extractDocumentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: extractDocument.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Api\V1\AiController::extractDocument
* @see app/Http/Controllers/Api/V1/AiController.php:0
* @route '/api/v1/ai/extract-document'
*/
extractDocumentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: extractDocument.url(options),
    method: 'post',
})

extractDocument.form = extractDocumentForm

const AiController = { generateContent, followUp, extractDocument }

export default AiController