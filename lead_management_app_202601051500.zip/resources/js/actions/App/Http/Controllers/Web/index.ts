import LeadController from './LeadController'
import LeadDocumentController from './LeadDocumentController'
import DashboardController from './DashboardController'
import OpportunityController from './OpportunityController'
import ProjectController from './ProjectController'
import PipelineController from './PipelineController'
import SupplierController from './SupplierController'
import HRController from './HRController'
import AccountingController from './AccountingController'
import ActivityController from './ActivityController'
import ConversationController from './ConversationController'
import VendorController from './VendorController'

const Web = {
    LeadController: Object.assign(LeadController, LeadController),
    LeadDocumentController: Object.assign(LeadDocumentController, LeadDocumentController),
    DashboardController: Object.assign(DashboardController, DashboardController),
    OpportunityController: Object.assign(OpportunityController, OpportunityController),
    ProjectController: Object.assign(ProjectController, ProjectController),
    PipelineController: Object.assign(PipelineController, PipelineController),
    SupplierController: Object.assign(SupplierController, SupplierController),
    HRController: Object.assign(HRController, HRController),
    AccountingController: Object.assign(AccountingController, AccountingController),
    ActivityController: Object.assign(ActivityController, ActivityController),
    ConversationController: Object.assign(ConversationController, ConversationController),
    VendorController: Object.assign(VendorController, VendorController),
}

export default Web