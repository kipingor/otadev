import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\AccountingController::index
* @see app/Http/Controllers/Web/AccountingController.php:11
* @route '/accounting'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accounting',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AccountingController::index
* @see app/Http/Controllers/Web/AccountingController.php:11
* @route '/accounting'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AccountingController::index
* @see app/Http/Controllers/Web/AccountingController.php:11
* @route '/accounting'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\AccountingController::index
* @see app/Http/Controllers/Web/AccountingController.php:11
* @route '/accounting'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\AccountingController::index
* @see app/Http/Controllers/Web/AccountingController.php:11
* @route '/accounting'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\AccountingController::index
* @see app/Http/Controllers/Web/AccountingController.php:11
* @route '/accounting'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\AccountingController::index
* @see app/Http/Controllers/Web/AccountingController.php:11
* @route '/accounting'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const AccountingController = { index }

export default AccountingController