import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/pipelines',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::index
* @see app/Http/Controllers/Web/PipelineController.php:13
* @route '/pipelines'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Web\PipelineController::create
* @see app/Http/Controllers/Web/PipelineController.php:38
* @route '/pipelines/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/pipelines/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\PipelineController::create
* @see app/Http/Controllers/Web/PipelineController.php:38
* @route '/pipelines/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\PipelineController::create
* @see app/Http/Controllers/Web/PipelineController.php:38
* @route '/pipelines/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::create
* @see app/Http/Controllers/Web/PipelineController.php:38
* @route '/pipelines/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::create
* @see app/Http/Controllers/Web/PipelineController.php:38
* @route '/pipelines/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::create
* @see app/Http/Controllers/Web/PipelineController.php:38
* @route '/pipelines/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::create
* @see app/Http/Controllers/Web/PipelineController.php:38
* @route '/pipelines/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Web\PipelineController::store
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pipelines',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\PipelineController::store
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\PipelineController::store
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::store
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::store
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Web\PipelineController::show
* @see app/Http/Controllers/Web/PipelineController.php:33
* @route '/pipelines/{pipeline}'
*/
export const show = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/pipelines/{pipeline}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\PipelineController::show
* @see app/Http/Controllers/Web/PipelineController.php:33
* @route '/pipelines/{pipeline}'
*/
show.url = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pipeline: args }
    }

    if (Array.isArray(args)) {
        args = {
            pipeline: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        pipeline: args.pipeline,
    }

    return show.definition.url
            .replace('{pipeline}', parsedArgs.pipeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\PipelineController::show
* @see app/Http/Controllers/Web/PipelineController.php:33
* @route '/pipelines/{pipeline}'
*/
show.get = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::show
* @see app/Http/Controllers/Web/PipelineController.php:33
* @route '/pipelines/{pipeline}'
*/
show.head = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::show
* @see app/Http/Controllers/Web/PipelineController.php:33
* @route '/pipelines/{pipeline}'
*/
const showForm = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::show
* @see app/Http/Controllers/Web/PipelineController.php:33
* @route '/pipelines/{pipeline}'
*/
showForm.get = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::show
* @see app/Http/Controllers/Web/PipelineController.php:33
* @route '/pipelines/{pipeline}'
*/
showForm.head = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Web\PipelineController::edit
* @see app/Http/Controllers/Web/PipelineController.php:43
* @route '/pipelines/{pipeline}/edit'
*/
export const edit = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/pipelines/{pipeline}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\PipelineController::edit
* @see app/Http/Controllers/Web/PipelineController.php:43
* @route '/pipelines/{pipeline}/edit'
*/
edit.url = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pipeline: args }
    }

    if (Array.isArray(args)) {
        args = {
            pipeline: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        pipeline: args.pipeline,
    }

    return edit.definition.url
            .replace('{pipeline}', parsedArgs.pipeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\PipelineController::edit
* @see app/Http/Controllers/Web/PipelineController.php:43
* @route '/pipelines/{pipeline}/edit'
*/
edit.get = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::edit
* @see app/Http/Controllers/Web/PipelineController.php:43
* @route '/pipelines/{pipeline}/edit'
*/
edit.head = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::edit
* @see app/Http/Controllers/Web/PipelineController.php:43
* @route '/pipelines/{pipeline}/edit'
*/
const editForm = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::edit
* @see app/Http/Controllers/Web/PipelineController.php:43
* @route '/pipelines/{pipeline}/edit'
*/
editForm.get = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::edit
* @see app/Http/Controllers/Web/PipelineController.php:43
* @route '/pipelines/{pipeline}/edit'
*/
editForm.head = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Web\PipelineController::update
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
export const update = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/pipelines/{pipeline}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Web\PipelineController::update
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
update.url = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pipeline: args }
    }

    if (Array.isArray(args)) {
        args = {
            pipeline: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        pipeline: args.pipeline,
    }

    return update.definition.url
            .replace('{pipeline}', parsedArgs.pipeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\PipelineController::update
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
update.put = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::update
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
update.patch = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::update
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
const updateForm = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::update
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
updateForm.put = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::update
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
updateForm.patch = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Web\PipelineController::destroy
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
export const destroy = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/pipelines/{pipeline}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\PipelineController::destroy
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
destroy.url = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pipeline: args }
    }

    if (Array.isArray(args)) {
        args = {
            pipeline: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        pipeline: args.pipeline,
    }

    return destroy.definition.url
            .replace('{pipeline}', parsedArgs.pipeline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\PipelineController::destroy
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
destroy.delete = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::destroy
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
const destroyForm = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\PipelineController::destroy
* @see app/Http/Controllers/Web/PipelineController.php:0
* @route '/pipelines/{pipeline}'
*/
destroyForm.delete = (args: { pipeline: string | number } | [pipeline: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const PipelineController = { index, create, store, show, edit, update, destroy }

export default PipelineController