<?php

namespace App\Http\Controllers\Web\Onboarding;

use App\Http\Controllers\Controller;
use App\Models\Module;
use App\Models\Subscription;
use App\Services\Tenant\SubscriptionService;
use App\Services\Tenant\TenantService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response as HttpResponse;
use Illuminate\Support\Facades\Log;
use Inertia\Inertia;
use Inertia\Response;

/**
 * SubscriptionController
 *
 * Handles plan upgrade, billing portal, cancellation, and
 * Stripe webhook processing.
 *
 * Pricing (keep in sync with Stripe dashboard + Subscription::monthlyPriceFor()):
 *   Free      $0    — 1 module, 1 user, 14-day trial
 *   Starter   $29/mo — 3 modules, 5 users
 *   Growth    $79/mo — all modules, 15 users
 *   Enterprise $199/mo — all modules, unlimited users + priority support
 */
class SubscriptionController extends Controller
{
    public function __construct(
        protected SubscriptionService $subscriptionService,
        protected TenantService $tenantService,
    ) {}

    /** Plan comparison / upgrade page */
    public function plans(Request $request): Response
    {
        $tenant       = $request->attributes->get('current_tenant');
        $subscription = $tenant?->subscription;
        $allModules   = Module::where('is_active', true)->orderBy('sort_order')->get();

        return Inertia::render('subscription/plans', [
            'tenant'       => $tenant,
            'subscription' => $subscription,
            'plans'        => $this->subscriptionService->getPlanDetails(),
            'all_modules'  => $allModules,
            'enabled_modules' => $tenant?->enabledModules->pluck('key'),
            'stripe_key'   => config('services.stripe.key'),
        ]);
    }

    /** Initiate a plan upgrade (creates/updates Stripe subscription) */
    public function upgrade(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'plan'           => ['required', 'in:starter,growth,enterprise'],
            'billing_cycle'  => ['required', 'in:monthly,annual'],
            'payment_method' => ['required', 'string'], // Stripe PaymentMethod ID
            'modules'        => ['nullable', 'array'],  // Module keys to enable
            'modules.*'      => ['string', 'exists:modules,key'],
        ]);

        $tenant = $request->attributes->get('current_tenant');

        try {
            $this->subscriptionService->upgrade(
                tenant: $tenant,
                plan: $data['plan'],
                billingCycle: $data['billing_cycle'],
                paymentMethodId: $data['payment_method'],
                moduleKeys: $data['modules'] ?? [],
            );

            return redirect()->route('web.dashboard')
                ->with('success', "Successfully upgraded to the {$data['plan']} plan!");

        } catch (\Exception $e) {
            Log::error('Subscription upgrade failed', [
                'tenant_id' => $tenant->id,
                'error'     => $e->getMessage(),
            ]);

            return back()->with('error', 'Upgrade failed: ' . $e->getMessage());
        }
    }

    /** Cancel subscription (downgrades to free at period end) */
    public function cancel(Request $request): RedirectResponse
    {
        $tenant = $request->attributes->get('current_tenant');

        $this->subscriptionService->cancel($tenant);

        return redirect()->route('subscription.plans')
            ->with('info', 'Your subscription has been cancelled. You can continue using the app until the end of your billing period.');
    }

    /** Stripe billing portal redirect */
    public function billing(Request $request): RedirectResponse
    {
        $tenant = $request->attributes->get('current_tenant');

        $portalUrl = $this->subscriptionService->getBillingPortalUrl(
            tenant: $tenant,
            returnUrl: route('subscription.plans'),
        );

        return redirect($portalUrl);
    }

    /** Trial expired wall page */
    public function expired(): Response
    {
        return Inertia::render('subscription/expired', [
            'plans' => $this->subscriptionService->getPlanDetails(),
        ]);
    }

    /** Suspended tenant page */
    public function suspended(): Response
    {
        return Inertia::render('subscription/suspended');
    }

    /**
     * Stripe webhook handler
     *
     * Stripe sends signed POST requests here for subscription lifecycle events:
     *   customer.subscription.updated  → sync plan/status changes
     *   customer.subscription.deleted  → downgrade to free
     *   invoice.payment_failed         → mark subscription past_due
     *   invoice.payment_succeeded      → confirm active status
     *
     * Route: POST /subscription/webhook/stripe  (no auth middleware)
     */
    public function stripeWebhook(Request $request): HttpResponse
    {
        $payload   = $request->getContent();
        $sigHeader = $request->header('Stripe-Signature');
        $secret    = config('services.stripe.webhook_secret');

        try {
            $event = \Stripe\Webhook::constructEvent($payload, $sigHeader, $secret);
        } catch (\Stripe\Exception\SignatureVerificationException $e) {
            Log::warning('Stripe webhook signature verification failed', ['error' => $e->getMessage()]);
            return response('Webhook signature verification failed.', 400);
        }

        try {
            $this->subscriptionService->handleStripeWebhook($event);
        } catch (\Exception $e) {
            Log::error('Stripe webhook processing failed', [
                'event_type' => $event->type,
                'error'      => $e->getMessage(),
            ]);
            // Return 200 so Stripe doesn't retry — log and investigate
            return response('Webhook processed with errors.', 200);
        }

        return response('Webhook handled.', 200);
    }
}