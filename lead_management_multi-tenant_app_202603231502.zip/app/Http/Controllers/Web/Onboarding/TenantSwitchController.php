<?php

namespace App\Http\Controllers\Web\Onboarding;

use App\Http\Controllers\Controller;
use App\Models\Tenant;
use App\Models\TenantUser;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Inertia\Response;

/**
 * TenantSwitchController
 *
 * Users who belong to multiple tenants (e.g. a consultant, or someone
 * who owns several companies) can switch their active workspace here.
 *
 * The active tenant is stored on users.current_tenant_id and read by
 * EnsureActiveTenant on every request.
 */
class TenantSwitchController extends Controller
{
    /** Show the workspace switcher page */
    public function index(): Response
    {
        $user = Auth::user();

        $memberships = TenantUser::where('user_id', $user->id)
            ->where('is_active', true)
            ->with(['tenant.subscription', 'tenant.enabledModules'])
            ->get()
            ->map(fn ($m) => [
                'tenant_id'       => $m->tenant_id,
                'name'            => $m->tenant->name,
                'slug'            => $m->tenant->slug,
                'plan'            => $m->tenant->plan,
                'logo_path'       => $m->tenant->logo_path,
                'role'            => $m->role,
                'is_current'      => $m->tenant_id === $user->current_tenant_id,
                'enabled_modules' => $m->tenant->enabledModules->pluck('key'),
            ]);

        return Inertia::render('onboarding/switch-tenant', [
            'memberships'       => $memberships,
            'current_tenant_id' => $user->current_tenant_id,
        ]);
    }

    /** Switch active workspace */
    public function switch(Request $request, string $tenantId): RedirectResponse
    {
        $user = Auth::user();

        // Verify the user actually belongs to this tenant
        $membership = TenantUser::where('tenant_id', $tenantId)
            ->where('user_id', $user->id)
            ->where('is_active', true)
            ->firstOrFail();

        $user->update(['current_tenant_id' => $tenantId]);

        // Update last active
        $membership->update(['last_active_at' => now()]);

        return redirect()->route('web.dashboard')
            ->with('success', "Switched to workspace: {$membership->tenant->name}");
    }

    /** Shortcut to create a new workspace while logged in */
    public function create(): RedirectResponse
    {
        return redirect()->route('onboarding.create');
    }
}