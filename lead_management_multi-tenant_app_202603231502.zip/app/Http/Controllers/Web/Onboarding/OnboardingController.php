<?php

namespace App\Http\Controllers\Web\Onboarding;

use App\Http\Controllers\Controller;
use App\Models\Module;
use App\Models\Tenant;
use App\Services\Tenant\TenantService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Inertia\Response;

/**
 * OnboardingController
 *
 * Handles the three-step post-registration flow:
 *   Step 1 — /onboarding/create       → workspace name, email, timezone, currency
 *   Step 2 — /onboarding/pick-module  → choose one free module (freemium)
 *   Step 3 — /onboarding/complete     → success + upgrade prompt
 *
 * ── BUG FIXES ───────────────────────────────────────────────────────────────
 *
 * Bug 1 (this caused the error):
 *   pickModule() had a fallback:
 *     return Inertia::render('onboarding/create');    ← NO props!
 *   When a user with no current_tenant_id hit /onboarding/pick-module,
 *   the create.tsx component rendered with timezones=undefined, throwing:
 *     TypeError: can't access property "map", timezones is undefined
 *
 *   Fix: replace the bare render with a redirect to the proper create route,
 *   which always passes the required props.
 *
 * Bug 2 (would have caused a similar crash on pick-module.tsx):
 *   create() had a fallback:
 *     return Inertia::render('onboarding/pick-module', ['free_modules' => ...]);
 *   This was missing the 'all_modules' and 'current_modules' props that
 *   pick-module.tsx destructures and calls .map() on.
 *
 *   Fix: redirect to the proper pick-module route so pickModule() builds
 *   all props correctly in one place.
 *
 * Rule: NEVER use Inertia::render() as a fallback for another page.
 *   If you need to show a different page, redirect() to its route so the
 *   responsible controller method assembles all required props.
 */
class OnboardingController extends Controller
{
    public function __construct(protected TenantService $tenantService) {}

    // ── Step 0: index redirect ────────────────────────────────────────────────

    public function index(): RedirectResponse
    {
        $user = Auth::user();

        if ($user->current_tenant_id) {
            return redirect()->route('web.dashboard');
        }

        return redirect()->route('onboarding.create');
    }

    // ── Step 1: workspace creation form ──────────────────────────────────────

    public function create(): Response|RedirectResponse
    {
        $user = Auth::user();

        // FIX: was Inertia::render('onboarding/pick-module', ['free_modules' => ...])
        // That rendered pick-module.tsx without 'all_modules' and 'current_modules' props,
        // which would crash when those arrays are mapped. Redirect instead.
        if ($user->current_tenant_id) {
            return redirect()->route('onboarding.pick-module');
        }

        return Inertia::render('onboarding/create', [
            'timezones' => timezone_identifiers_list(),
            'currencies' => ['USD', 'KES', 'EUR', 'GBP', 'ZAR', 'NGN', 'GHS'],
        ]);
    }

    // ── Step 1 submit ─────────────────────────────────────────────────────────

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name'     => ['required', 'string', 'max:100'],
            'email'    => ['required', 'email', 'max:150'],
            'phone'    => ['nullable', 'string', 'max:20'],
            'timezone' => ['required', 'string', 'timezone'],
            'currency' => ['required', 'string', 'size:3'],
        ]);

        $user   = Auth::user();
        $tenant = $this->tenantService->createTenant($user, $data);

        return redirect()->route('onboarding.pick-module');
    }

    // ── Step 2: module picker ─────────────────────────────────────────────────

    public function pickModule(): Response|RedirectResponse
    {
        $user = Auth::user();

        // FIX: was Inertia::render('onboarding/create') with NO props.
        // The create page requires 'timezones' (string[]) and 'currencies' (string[]).
        // Rendering it without those props caused:
        //   TypeError: can't access property "map", timezones is undefined
        // Redirect instead — the create() method passes the props correctly.
        if (!$user->current_tenant_id) {
            return redirect()->route('onboarding.create');
        }

        $tenant = Tenant::find($user->current_tenant_id);

        return Inertia::render('onboarding/pick-module', [
            'free_modules'    => Module::freeModules(),
            'all_modules'     => Module::where('is_active', true)->orderBy('sort_order')->get(),
            'current_modules' => $tenant
                ? $tenant->enabledModules->pluck('key')->values()->toArray()
                : [],
        ]);
    }

    // ── Step 2 submit ─────────────────────────────────────────────────────────

    public function saveModule(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'module_key' => ['required', 'string', 'exists:modules,key'],
        ]);

        $user   = Auth::user();
        $tenant = Tenant::findOrFail($user->current_tenant_id);

        // Verify the chosen module is actually free
        $module = Module::where('key', $data['module_key'])
            ->where('is_free', true)
            ->where('is_active', true)
            ->firstOrFail();

        // Free plan = 1 module max: disable any previously enabled modules
        $tenant->tenantModules()->update(['is_enabled' => false]);

        $tenant->enableModule($module->key);

        return redirect()->route('onboarding.complete');
    }

    // ── Step 3: completion screen ─────────────────────────────────────────────

    public function complete(): Response|RedirectResponse
    {
        $user   = Auth::user();
        $tenant = Tenant::find($user->current_tenant_id);

        // If they somehow reach complete without a tenant, send them back to start
        if (!$tenant) {
            return redirect()->route('onboarding.create');
        }

        return Inertia::render('onboarding/complete', [
            'tenant'          => $tenant,
            'enabled_modules' => $tenant->enabledModules->pluck('key')->values(),
            'upgrade_plans'   => $this->tenantService->getPlanComparison(),
        ]);
    }
}