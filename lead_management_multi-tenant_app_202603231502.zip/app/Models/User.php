<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Fortify\TwoFactorAuthenticatable;
use Spatie\Permission\Traits\HasRoles;
use App\Models\Concerns\HasTenantScope;

class User extends Authenticatable
{
    use HasFactory, Notifiable, TwoFactorAuthenticatable, HasRoles, HasTenantScope;

    protected $fillable = [
        'name',
        'email',
        'password',
        'avatar',
        'role',

        // ── MULTITENANCY ──────────────────────────────────────────────────────
        // FIX: 'current_tenant_id' was missing from $fillable.
        //
        // Eloquent's mass assignment protection silently discards any key not
        // listed here when you call $model->update([...]) or Model::create([...]).
        //
        // Every call to $user->update(['current_tenant_id' => $id]) across the
        // entire app was silently doing nothing:
        //   - TenantService::createTenant()   → tenant created, but user's
        //     current_tenant_id stayed null   → redirect to pick-module
        //     → pickModule() checks current_tenant_id → null → redirect back
        //     to create → infinite loop stuck on /onboarding/create
        //   - TenantSwitchController::switch() → workspace never switched
        //   - SuperAdminTenantController::impersonate() → impersonation broken
        //
        // Adding it here fixes all three in one change.
        'current_tenant_id',

        // Client fields (previously separate Client model)
        'is_client',
        'client_since',
        'company',
        'phone',
        'address',
        'website',
        'notes',
    ];

    protected $hidden = ['password', 'remember_token'];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password'          => 'hashed',
        'is_client'         => 'boolean',
        'client_since'      => 'date',
    ];

    // ── Tenant Relations ──────────────────────────────────────────────────────

    /** The tenant currently active for this user's session. */
    public function currentTenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class, 'current_tenant_id', 'id');
    }

    /** All tenants this user belongs to. */
    public function tenants(): BelongsToMany
    {
        return $this->belongsToMany(Tenant::class, 'tenant_users', 'user_id', 'tenant_id')
            ->withPivot(['role', 'is_active', 'joined_at', 'last_active_at'])
            ->withTimestamps();
    }

    /** The TenantUser pivot row for the current tenant. */
    public function currentTenantMembership(): ?TenantUser
    {
        if (!$this->current_tenant_id) {
            return null;
        }
        return TenantUser::where('tenant_id', $this->current_tenant_id)
            ->where('user_id', $this->id)
            ->first();
    }

    /** Role this user holds inside a given tenant. */
    public function tenantRole(string $tenantId): ?string
    {
        $pivot = TenantUser::where('tenant_id', $tenantId)
            ->where('user_id', $this->id)
            ->first();
        return $pivot?->role;
    }

    public function isOwnerOf(Tenant $tenant): bool
    {
        return $this->tenantRole($tenant->id) === 'owner';
    }

    public function isAdminOf(Tenant $tenant): bool
    {
        return in_array($this->tenantRole($tenant->id), ['owner', 'admin']);
    }

    // ── Client Scopes ─────────────────────────────────────────────────────────

    public function scopeClients(Builder $query): Builder
    {
        return $query->where('is_client', true);
    }

    public function scopeClient(Builder $query): Builder
    {
        return $query->where('is_client', true);
    }

    public function scopeForTenant(Builder $query, string $tenantId): Builder
    {
        return $query->whereHas('tenants', fn ($q) => $q->where('tenant_id', $tenantId));
    }

    public function convertToClient(): static
    {
        $this->update([
            'is_client'    => true,
            'client_since' => $this->client_since ?? now(),
        ]);
        return $this;
    }

    // ── Relations ─────────────────────────────────────────────────────────────

    public function projects(): HasMany
    {
        return $this->hasMany(Project::class, 'client_id');
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class, 'client_id');
    }

    public function clientFollowUps(): HasMany
    {
        return $this->hasMany(ClientFollowUp::class, 'client_id');
    }

    public function clientReports(): HasMany
    {
        return $this->hasMany(ClientReport::class, 'client_id');
    }

    public function leads(): HasMany
    {
        return $this->hasMany(Lead::class, 'client_id');
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function getIsClientAttribute(): bool
    {
        return (bool) $this->attributes['is_client'];
    }

    public function getDisplayRoleAttribute(): string
    {
        return $this->is_client ? 'Client' : ucfirst($this->role ?? 'user');
    }
}
