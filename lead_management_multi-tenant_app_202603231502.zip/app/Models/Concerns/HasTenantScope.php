<?php

namespace App\Models\Concerns;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

/**
 * HasTenantScope
 *
 * Applies an automatic tenant_id WHERE clause to every Eloquent query
 * on models that use this trait. Add to any primary model:
 *
 *   use HasFactory, SoftDeletes, HasTenantScope;
 *
 * The current tenant is read from the service container, bound by
 * EnsureActiveTenant middleware:
 *   app()->instance('current_tenant', $tenant);
 *
 * When no tenant is in context (artisan, seeders, super-admin) the scope
 * is silent — queries return all rows unfiltered.
 *
 * ── BUG FIX ──────────────────────────────────────────────────────────────────
 *
 * The previous version had a helper named currentTenant(). The User model
 * also has a currentTenant() Eloquent relation (instance method). When PHP
 * resolves method calls inside trait closures, the class method takes
 * precedence over the trait's static method. Calling self::currentTenant()
 * then tried to invoke User's BelongsTo relation statically, throwing:
 *
 *   "Non-static method App\Models\User::currentTenant() cannot be called statically"
 *
 * Fix: renamed the private static helper to resolveTenantFromContainer()
 * — a name that cannot collide with any Eloquent relation.
 */
trait HasTenantScope
{
    public static function bootHasTenantScope(): void
    {
        // ── Global scope: WHERE tenant_id = current_tenant_id ─────────────────
        static::addGlobalScope('tenant', function (Builder $query) {
            $tenant = self::resolveTenantFromContainer();
            if ($tenant) {
                $query->where(
                    (new static)->getTable() . '.tenant_id',
                    $tenant->id
                );
            }
        });

        // ── Creating event: auto-inject tenant_id ─────────────────────────────
        static::creating(function (Model $model) {
            if (empty($model->tenant_id)) {
                $tenant = self::resolveTenantFromContainer();
                if ($tenant) {
                    $model->tenant_id = $tenant->id;
                }
            }
        });
    }

    /**
     * Read the current tenant from the service container.
     *
     * Named resolveTenantFromContainer() (not currentTenant()) to avoid
     * collision with App\Models\User::currentTenant() which is a BelongsTo
     * Eloquent relation (instance method). PHP's MRO gives instance class
     * methods priority over trait methods, so a same-named instance method
     * on the host class would shadow the trait's static, causing a fatal
     * "cannot be called statically" error.
     *
     * Returns null outside of a tenant request context (artisan, seeders,
     * central routes) so those flows work without tenant filtering.
     */
    protected static function resolveTenantFromContainer(): ?\App\Models\Tenant
    {
        try {
            if (app()->bound('current_tenant')) {
                return app('current_tenant');
            }
        } catch (\Throwable) {
            // Container not fully booted yet (early bootstrapping)
        }

        return null;
    }

    /**
     * Bypass the tenant scope for a query — use in super-admin or
     * cross-tenant reporting contexts.
     *
     * Usage:
     *   Lead::withoutTenantScope()->where('status', 'won')->get();
     */
    public static function withoutTenantScope(): Builder
    {
        return static::withoutGlobalScope('tenant');
    }

    /**
     * Alias — reads more clearly in reporting code.
     *
     * Usage:
     *   Lead::allTenants()->groupBy('tenant_id')->count();
     */
    public static function allTenants(): Builder
    {
        return static::withoutTenantScope();
    }
}