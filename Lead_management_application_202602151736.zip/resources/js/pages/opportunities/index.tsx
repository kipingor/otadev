import AppLayout from '@/layouts/app-layout';
import { usePage } from '@inertiajs/react';
import OpportunityCard from '@/pages/opportunities/opportunity-card';
import { PageHeader } from '@/components/PageHeader';
import { Plus } from 'lucide-react';

export default function OpportunitiesIndex() {
    const { opportunities } = usePage<{ opportunities: { data: any[] } }>()
        .props;
    const items = opportunities?.data ?? [];

    return (
        <AppLayout>
            <div className="flex h-full flex-1 flex-col gap-8 p-6">
                {/* Header with title and "New Opportunity" button */}
                <PageHeader
                    title="Opportunities"
                    description="Manage your sales opportunities and track potential deals."
                    breadcrumbs={[
                        { label: 'Dashboard', href: '/dashboard' },
                        { label: 'Opportunities', href: '/opportunities' },
                    ]}
                    backButton={{
                        label: 'Back to Dashboard',
                        href: '/dashboard',
                    }}
                    actions={[
                        {
                            label: 'New Opportunity',
                            href: '/opportunities/create',
                            icon: Plus,
                        },
                    ]}
                />

                <div className="grid gap-6 grid-col-1 lg:grid-cols-2 mt-4">
                    {items.map((opportunity: any) => (
                        <OpportunityCard
                            key={opportunity.id}
                            opportunity={opportunity}
                        />
                    ))}
                </div>
            </div>
        </AppLayout>
    );
}
