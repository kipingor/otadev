import { useState } from 'react';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Loader2, AlertTriangle, Info, CheckCircle, XCircle } from 'lucide-react';

type ConfirmVariant = 'danger' | 'warning' | 'info' | 'success';

interface ConfirmDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    title: string;
    description?: string;
    confirmLabel?: string;
    cancelLabel?: string;
    variant?: ConfirmVariant;
    onConfirm: () => void | Promise<void>;
    loading?: boolean;
}

const VARIANT_CONFIG: Record<ConfirmVariant, {
    icon: typeof AlertTriangle;
    iconColor: string;
    actionVariant: 'default' | 'destructive';
}> = {
    danger: {
        icon: XCircle,
        iconColor: 'text-destructive',
        actionVariant: 'destructive',
    },
    warning: {
        icon: AlertTriangle,
        iconColor: 'text-orange-500',
        actionVariant: 'default',
    },
    info: {
        icon: Info,
        iconColor: 'text-blue-500',
        actionVariant: 'default',
    },
    success: {
        icon: CheckCircle,
        iconColor: 'text-green-500',
        actionVariant: 'default',
    },
};

export function ConfirmDialog({
    open,
    onOpenChange,
    title,
    description,
    confirmLabel = 'Confirm',
    cancelLabel = 'Cancel',
    variant = 'danger',
    onConfirm,
    loading = false,
}: ConfirmDialogProps) {
    const config = VARIANT_CONFIG[variant];
    const Icon = config.icon;

    const handleConfirm = async () => {
        await onConfirm();
    };

    return (
        <AlertDialog open={open} onOpenChange={onOpenChange}>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <div className="flex items-start gap-3">
                        <div className={`rounded-full p-2 ${variant === 'danger' ? 'bg-destructive/10' : 'bg-muted'}`}>
                            <Icon className={`h-5 w-5 ${config.iconColor}`} />
                        </div>
                        <div className="flex-1">
                            <AlertDialogTitle>{title}</AlertDialogTitle>
                            {description && (
                                <AlertDialogDescription className="mt-2">
                                    {description}
                                </AlertDialogDescription>
                            )}
                        </div>
                    </div>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel disabled={loading}>
                        {cancelLabel}
                    </AlertDialogCancel>
                    <AlertDialogAction
                        onClick={(e) => {
                            e.preventDefault();
                            handleConfirm();
                        }}
                        disabled={loading}
                        className={config.actionVariant === 'destructive' ? 'bg-destructive text-destructive-foreground hover:bg-destructive/90' : ''}
                    >
                        {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {confirmLabel}
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
}

// Hook for easier usage
export function useConfirmDialog() {
    const [open, setOpen] = useState(false);
    const [config, setConfig] = useState<Omit<ConfirmDialogProps, 'open' | 'onOpenChange'>>({
        title: '',
        description: '',
        onConfirm: () => {},
    });

    const confirm = (options: Omit<ConfirmDialogProps, 'open' | 'onOpenChange'>) => {
        return new Promise<boolean>((resolve) => {
            setConfig({
                ...options,
                onConfirm: async () => {
                    await options.onConfirm();
                    setOpen(false);
                    resolve(true);
                },
            });
            setOpen(true);
        });
    };

    const ConfirmDialogComponent = () => (
        <ConfirmDialog
            open={open}
            onOpenChange={(value) => {
                setOpen(value);
                if (!value) {
                    // User cancelled
                }
            }}
            {...config}
        />
    );

    return {
        confirm,
        ConfirmDialog: ConfirmDialogComponent,
    };
}

// Quick confirmation functions
export function useDeleteConfirmation() {
    const { confirm, ConfirmDialog } = useConfirmDialog();

    const confirmDelete = (itemName?: string) => {
        return confirm({
            title: 'Are you sure?',
            description: itemName
                ? `This will permanently delete "${itemName}". This action cannot be undone.`
                : 'This will permanently delete this item. This action cannot be undone.',
            confirmLabel: 'Delete',
            cancelLabel: 'Cancel',
            variant: 'danger',
            onConfirm: () => {},
        });
    };

    return { confirmDelete, ConfirmDialog };
}