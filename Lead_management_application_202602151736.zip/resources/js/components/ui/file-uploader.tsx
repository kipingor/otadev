import { useState, useRef, DragEvent, ChangeEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Upload, X, File, FileText, Image, FileCode, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FileWithPreview extends File {
    preview?: string;
}

interface FileUploaderProps {
    accept?: string;
    maxSize?: number; // in MB
    maxFiles?: number;
    multiple?: boolean;
    value?: FileWithPreview[];
    onChange?: (files: FileWithPreview[]) => void;
    onUpload?: (files: FileWithPreview[]) => Promise<void>;
    disabled?: boolean;
    className?: string;
}

export function FileUploader({
    accept,
    maxSize = 10, // 10MB default
    maxFiles = 5,
    multiple = true,
    value = [],
    onChange,
    onUpload,
    disabled = false,
    className,
}: FileUploaderProps) {
    const [files, setFiles] = useState<FileWithPreview[]>(value);
    const [isDragging, setIsDragging] = useState(false);
    const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
    const [errors, setErrors] = useState<string[]>([]);
    const inputRef = useRef<HTMLInputElement>(null);

    // File validation
    const validateFile = (file: File): string | null => {
        // Check file size
        if (file.size > maxSize * 1024 * 1024) {
            return `${file.name} is too large. Maximum size is ${maxSize}MB.`;
        }

        // Check file type
        if (accept) {
            const acceptedTypes = accept.split(',').map(type => type.trim());
            const fileExtension = '.' + file.name.split('.').pop();
            const mimeType = file.type;

            const isAccepted = acceptedTypes.some(type => {
                if (type.startsWith('.')) {
                    return fileExtension.toLowerCase() === type.toLowerCase();
                }
                if (type.endsWith('/*')) {
                    return mimeType.startsWith(type.replace('/*', ''));
                }
                return mimeType === type;
            });

            if (!isAccepted) {
                return `${file.name} is not an accepted file type.`;
            }
        }

        return null;
    };

    // Handle file selection
    const handleFiles = (newFiles: FileList | null) => {
        if (!newFiles) return;

        const filesArray = Array.from(newFiles);
        const validationErrors: string[] = [];

        // Check max files
        if (files.length + filesArray.length > maxFiles) {
            validationErrors.push(`Maximum ${maxFiles} files allowed.`);
            setErrors(validationErrors);
            return;
        }

        // Validate each file
        const validFiles: FileWithPreview[] = [];
        filesArray.forEach(file => {
            const error = validateFile(file);
            if (error) {
                validationErrors.push(error);
            } else {
                // Add preview for images
                const fileWithPreview = file as FileWithPreview;
                if (file.type.startsWith('image/')) {
                    fileWithPreview.preview = URL.createObjectURL(file);
                }
                validFiles.push(fileWithPreview);
            }
        });

        setErrors(validationErrors);

        if (validFiles.length > 0) {
            const updatedFiles = [...files, ...validFiles];
            setFiles(updatedFiles);
            onChange?.(updatedFiles);
        }
    };

    // Drag and drop handlers
    const handleDragEnter = (e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        if (!disabled) {
            setIsDragging(true);
        }
    };

    const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
    };

    const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
    };

    const handleDrop = (e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);

        if (!disabled) {
            handleFiles(e.dataTransfer.files);
        }
    };

    // Input change handler
    const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
        handleFiles(e.target.files);
    };

    // Remove file
    const removeFile = (index: number) => {
        const updatedFiles = files.filter((_, i) => i !== index);
        setFiles(updatedFiles);
        onChange?.(updatedFiles);

        // Revoke preview URL
        if (files[index].preview) {
            URL.revokeObjectURL(files[index].preview!);
        }
    };

    // Upload files
    const handleUpload = async () => {
        if (onUpload) {
            await onUpload(files);
        }
    };

    // Get file icon
    const getFileIcon = (file: File) => {
        if (file.type.startsWith('image/')) return Image;
        if (file.type.startsWith('text/')) return FileText;
        if (file.type.includes('pdf')) return File;
        if (file.type.includes('code')) return FileCode;
        return File;
    };

    return (
        <div className={cn('space-y-4', className)}>
            {/* Drop zone */}
            <div
                onDragEnter={handleDragEnter}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={cn(
                    'relative rounded-lg border-2 border-dashed transition-colors',
                    isDragging ? 'border-primary bg-primary/5' : 'border-muted-foreground/25',
                    disabled && 'opacity-50 cursor-not-allowed'
                )}
            >
                <input
                    ref={inputRef}
                    type="file"
                    accept={accept}
                    multiple={multiple}
                    onChange={handleInputChange}
                    disabled={disabled}
                    className="hidden"
                />

                <div className="flex flex-col items-center justify-center p-8 text-center">
                    <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-sm font-medium mb-1">
                        Drop files here or click to browse
                    </p>
                    <p className="text-xs text-muted-foreground mb-4">
                        {accept ? `Accepted: ${accept}` : 'Any file type'} • Max {maxSize}MB • Up to {maxFiles} files
                    </p>
                    <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => inputRef.current?.click()}
                        disabled={disabled}
                    >
                        Select Files
                    </Button>
                </div>
            </div>

            {/* Errors */}
            {errors.length > 0 && (
                <div className="space-y-2">
                    {errors.map((error, index) => (
                        <div key={index} className="flex items-start gap-2 text-sm text-destructive">
                            <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                            <span>{error}</span>
                        </div>
                    ))}
                </div>
            )}

            {/* File list */}
            {files.length > 0 && (
                <div className="space-y-2">
                    <h3 className="text-sm font-medium">Selected Files ({files.length})</h3>
                    <div className="space-y-2">
                        {files.map((file, index) => {
                            const Icon = getFileIcon(file);
                            const progress = uploadProgress[file.name];

                            return (
                                <Card key={index} className="p-3">
                                    <div className="flex items-start gap-3">
                                        {/* Preview or icon */}
                                        {file.preview ? (
                                            <img
                                                src={file.preview}
                                                alt={file.name}
                                                className="h-12 w-12 rounded object-cover"
                                            />
                                        ) : (
                                            <div className="rounded bg-muted p-2">
                                                <Icon className="h-6 w-6 text-muted-foreground" />
                                            </div>
                                        )}

                                        {/* File info */}
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-medium truncate">
                                                {file.name}
                                            </p>
                                            <p className="text-xs text-muted-foreground">
                                                {(file.size / 1024 / 1024).toFixed(2)} MB
                                            </p>

                                            {/* Progress bar */}
                                            {progress !== undefined && (
                                                <Progress value={progress} className="h-1 mt-2" />
                                            )}
                                        </div>

                                        {/* Remove button */}
                                        <Button
                                            type="button"
                                            variant="ghost"
                                            size="icon"
                                            onClick={() => removeFile(index)}
                                            disabled={disabled}
                                        >
                                            <X className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </Card>
                            );
                        })}
                    </div>

                    {/* Upload button */}
                    {onUpload && (
                        <Button
                            onClick={handleUpload}
                            disabled={disabled || files.length === 0}
                            className="w-full"
                        >
                            Upload {files.length} {files.length === 1 ? 'File' : 'Files'}
                        </Button>
                    )}
                </div>
            )}
        </div>
    );
}