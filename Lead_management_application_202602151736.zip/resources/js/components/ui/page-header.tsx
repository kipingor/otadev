import { Button } from '@/components/ui/button';
import { Link } from '@inertiajs/react';
import { ArrowLeft, LucideIcon } from 'lucide-react';
import { Breadcrumbs } from '@/components/breadcrumbs';
import { cn } from '@/lib/utils';
import { type BreadcrumbItem } from '@/types';
import { type ReactNode } from 'react';

interface PageHeaderAction {
    label: string;
    href?: string;
    onClick?: () => void;
    variant?: 'default' | 'outline' | 'secondary' | 'ghost' | 'destructive';
    icon?: LucideIcon;
}

interface PageHeaderProps {
    title: string;
    description?: string;
    breadcrumbs?: BreadcrumbItem[];
    actions?: ReactNode;
    backButton?: {
        label?: string;
        href: string;
    };
    className?: string;
}

export function PageHeader({
    title,
    description,
    breadcrumbs,
    actions,
    backButton,
    className = '',
}: PageHeaderProps) {
    return (
        <div className={`space-y-4 ${className}`}>
            {breadcrumbs && breadcrumbs.length > 0 && (
                <Breadcrumbs breadcrumbs={breadcrumbs} />
            )}
            {/* Back Button */}
            {backButton && (
                <Button asChild variant="ghost" size="sm" className="-ml-2">
                    <Link href={backButton.href}>
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        {backButton.label || 'Back'}
                    </Link>
                </Button>
            )}

            {/* Header Content */}
            <div className="flex items-start justify-between gap-4">
                {/* Title and Description */}
                <div className="space-y-1">
                    <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
                    {description && (
                        <p className="text-muted-foreground">{description}</p>
                    )}
                </div>

                {/* Actions */}
                {Array.isArray(actions) && actions.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                        {actions.map((action, index) => {
                            const Icon = action.icon;
                            if (action.href) {
                                return (
                                    <Button
                                        key={index}
                                        asChild
                                        variant={action.variant || 'default'}
                                    >
                                        <Link href={action.href}>
                                            {Icon && <Icon className="mr-2 h-4 w-4" />}
                                            {action.label}
                                        </Link>
                                    </Button>
                                );
                            }

                            return (
                                <Button
                                    key={index}
                                    onClick={action.onClick}
                                    variant={action.variant || 'default'}
                                >
                                    {Icon && <Icon className="mr-2 h-4 w-4" />}
                                    {action.label}
                                </Button>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
}

// Compact variant for less important pages
export function PageHeaderCompact({
    title,
    description,
    action,
}: {
    title: string;
    description?: string;
    action?: PageHeaderAction;
}) {
    return (
        <div className="flex items-center justify-between">
            <div>
                <h2 className="text-2xl font-bold">{title}</h2>
                {description && (
                    <p className="text-sm text-muted-foreground mt-1">{description}</p>
                )}
            </div>
            {action && (
                <Button
                    asChild={!!action.href}
                    onClick={action.onClick}
                    variant={action.variant}
                >
                    {action.href ? (
                        <Link href={action.href}>
                            {action.icon && <action.icon className="mr-2 h-4 w-4" />}
                            {action.label}
                        </Link>
                    ) : (
                        <>
                            {action.icon && <action.icon className="mr-2 h-4 w-4" />}
                            {action.label}
                        </>
                    )}
                </Button>
            )}
        </div>
    );
}