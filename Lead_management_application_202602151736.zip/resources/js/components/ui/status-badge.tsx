import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { LeadStatus } from '@/types/models';
import {
    Circle, 
    Phone, 
    CheckCircle, 
    FileText, 
    Handshake, 
    Trophy, 
    XCircle, 
    Archive 
} from 'lucide-react';

interface StatusBadgeProps {
    status: LeadStatus | string;
    showIcon?: boolean;
    className?: string;
}

const STATUS_CONFIG: Record<LeadStatus, {
    label: string;
    variant: 'default' | 'secondary' | 'destructive' | 'outline';
    icon: typeof Circle;
    className: string;
}> = {
    new: {
        label: 'New',
        variant: 'default',
        icon: Circle,
        className: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    },
    contacted: {
        label: 'Contacted',
        variant: 'secondary',
        icon: Phone,
        className: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
    },
    qualified: {
        label: 'Qualified',
        variant: 'secondary',
        icon: CheckCircle,
        className: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
    },
    proposal_sent: {
        label: 'Proposal Sent',
        variant: 'secondary',
        icon: FileText,
        className: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200',
    },
    negotiation: {
        label: 'Negotiation',
        variant: 'secondary',
        icon: Handshake,
        className: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
    },
    won: {
        label: 'Won',
        variant: 'default',
        icon: Trophy,
        className: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    },
    lost: {
        label: 'Lost',
        variant: 'destructive',
        icon: XCircle,
        className: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
    },
    archived: {
        label: 'Archived',
        variant: 'outline',
        icon: Archive,
        className: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200',
    },
};

export function StatusBadge({ status, showIcon = true, className }: StatusBadgeProps) {
    const config = STATUS_CONFIG[status];

    const Icon = config.icon;

    return (
        <Badge
            variant={config.variant}
            className={cn(config.className, className)}
        >
            {showIcon && <Icon className="mr-1 h-3 w-3" />}
            {config.label}
        </Badge>
    );
}