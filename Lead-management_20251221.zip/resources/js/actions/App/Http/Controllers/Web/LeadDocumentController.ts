import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\LeadDocumentController::index
* @see app/Http/Controllers/Web/LeadDocumentController.php:17
* @route '/leads/{lead}/documents'
*/
export const index = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/leads/{lead}/documents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::index
* @see app/Http/Controllers/Web/LeadDocumentController.php:17
* @route '/leads/{lead}/documents'
*/
index.url = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lead: args }
    }

    if (Array.isArray(args)) {
        args = {
            lead: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        lead: args.lead,
    }

    return index.definition.url
            .replace('{lead}', parsedArgs.lead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::index
* @see app/Http/Controllers/Web/LeadDocumentController.php:17
* @route '/leads/{lead}/documents'
*/
index.get = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::index
* @see app/Http/Controllers/Web/LeadDocumentController.php:17
* @route '/leads/{lead}/documents'
*/
index.head = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::index
* @see app/Http/Controllers/Web/LeadDocumentController.php:17
* @route '/leads/{lead}/documents'
*/
const indexForm = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::index
* @see app/Http/Controllers/Web/LeadDocumentController.php:17
* @route '/leads/{lead}/documents'
*/
indexForm.get = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::index
* @see app/Http/Controllers/Web/LeadDocumentController.php:17
* @route '/leads/{lead}/documents'
*/
indexForm.head = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::create
* @see app/Http/Controllers/Web/LeadDocumentController.php:24
* @route '/leads/{lead}/documents/create'
*/
export const create = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/leads/{lead}/documents/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::create
* @see app/Http/Controllers/Web/LeadDocumentController.php:24
* @route '/leads/{lead}/documents/create'
*/
create.url = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lead: args }
    }

    if (Array.isArray(args)) {
        args = {
            lead: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        lead: args.lead,
    }

    return create.definition.url
            .replace('{lead}', parsedArgs.lead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::create
* @see app/Http/Controllers/Web/LeadDocumentController.php:24
* @route '/leads/{lead}/documents/create'
*/
create.get = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::create
* @see app/Http/Controllers/Web/LeadDocumentController.php:24
* @route '/leads/{lead}/documents/create'
*/
create.head = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::create
* @see app/Http/Controllers/Web/LeadDocumentController.php:24
* @route '/leads/{lead}/documents/create'
*/
const createForm = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::create
* @see app/Http/Controllers/Web/LeadDocumentController.php:24
* @route '/leads/{lead}/documents/create'
*/
createForm.get = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::create
* @see app/Http/Controllers/Web/LeadDocumentController.php:24
* @route '/leads/{lead}/documents/create'
*/
createForm.head = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::store
* @see app/Http/Controllers/Web/LeadDocumentController.php:29
* @route '/leads/{lead}/documents'
*/
export const store = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/leads/{lead}/documents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::store
* @see app/Http/Controllers/Web/LeadDocumentController.php:29
* @route '/leads/{lead}/documents'
*/
store.url = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lead: args }
    }

    if (Array.isArray(args)) {
        args = {
            lead: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        lead: args.lead,
    }

    return store.definition.url
            .replace('{lead}', parsedArgs.lead.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::store
* @see app/Http/Controllers/Web/LeadDocumentController.php:29
* @route '/leads/{lead}/documents'
*/
store.post = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::store
* @see app/Http/Controllers/Web/LeadDocumentController.php:29
* @route '/leads/{lead}/documents'
*/
const storeForm = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::store
* @see app/Http/Controllers/Web/LeadDocumentController.php:29
* @route '/leads/{lead}/documents'
*/
storeForm.post = (args: { lead: string | number } | [lead: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::show
* @see app/Http/Controllers/Web/LeadDocumentController.php:37
* @route '/lead-documents/{document}'
*/
export const show = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/lead-documents/{document}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::show
* @see app/Http/Controllers/Web/LeadDocumentController.php:37
* @route '/lead-documents/{document}'
*/
show.url = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { document: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            document: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        document: typeof args.document === 'object'
        ? args.document.id
        : args.document,
    }

    return show.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::show
* @see app/Http/Controllers/Web/LeadDocumentController.php:37
* @route '/lead-documents/{document}'
*/
show.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::show
* @see app/Http/Controllers/Web/LeadDocumentController.php:37
* @route '/lead-documents/{document}'
*/
show.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::show
* @see app/Http/Controllers/Web/LeadDocumentController.php:37
* @route '/lead-documents/{document}'
*/
const showForm = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::show
* @see app/Http/Controllers/Web/LeadDocumentController.php:37
* @route '/lead-documents/{document}'
*/
showForm.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::show
* @see app/Http/Controllers/Web/LeadDocumentController.php:37
* @route '/lead-documents/{document}'
*/
showForm.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::edit
* @see app/Http/Controllers/Web/LeadDocumentController.php:42
* @route '/lead-documents/{document}/edit'
*/
export const edit = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/lead-documents/{document}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::edit
* @see app/Http/Controllers/Web/LeadDocumentController.php:42
* @route '/lead-documents/{document}/edit'
*/
edit.url = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { document: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            document: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        document: typeof args.document === 'object'
        ? args.document.id
        : args.document,
    }

    return edit.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::edit
* @see app/Http/Controllers/Web/LeadDocumentController.php:42
* @route '/lead-documents/{document}/edit'
*/
edit.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::edit
* @see app/Http/Controllers/Web/LeadDocumentController.php:42
* @route '/lead-documents/{document}/edit'
*/
edit.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::edit
* @see app/Http/Controllers/Web/LeadDocumentController.php:42
* @route '/lead-documents/{document}/edit'
*/
const editForm = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::edit
* @see app/Http/Controllers/Web/LeadDocumentController.php:42
* @route '/lead-documents/{document}/edit'
*/
editForm.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::edit
* @see app/Http/Controllers/Web/LeadDocumentController.php:42
* @route '/lead-documents/{document}/edit'
*/
editForm.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::update
* @see app/Http/Controllers/Web/LeadDocumentController.php:47
* @route '/lead-documents/{document}'
*/
export const update = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/lead-documents/{document}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::update
* @see app/Http/Controllers/Web/LeadDocumentController.php:47
* @route '/lead-documents/{document}'
*/
update.url = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { document: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            document: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        document: typeof args.document === 'object'
        ? args.document.id
        : args.document,
    }

    return update.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::update
* @see app/Http/Controllers/Web/LeadDocumentController.php:47
* @route '/lead-documents/{document}'
*/
update.put = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::update
* @see app/Http/Controllers/Web/LeadDocumentController.php:47
* @route '/lead-documents/{document}'
*/
const updateForm = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::update
* @see app/Http/Controllers/Web/LeadDocumentController.php:47
* @route '/lead-documents/{document}'
*/
updateForm.put = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::destroy
* @see app/Http/Controllers/Web/LeadDocumentController.php:55
* @route '/lead-documents/{document}'
*/
export const destroy = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/lead-documents/{document}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::destroy
* @see app/Http/Controllers/Web/LeadDocumentController.php:55
* @route '/lead-documents/{document}'
*/
destroy.url = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { document: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            document: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        document: typeof args.document === 'object'
        ? args.document.id
        : args.document,
    }

    return destroy.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::destroy
* @see app/Http/Controllers/Web/LeadDocumentController.php:55
* @route '/lead-documents/{document}'
*/
destroy.delete = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::destroy
* @see app/Http/Controllers/Web/LeadDocumentController.php:55
* @route '/lead-documents/{document}'
*/
const destroyForm = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::destroy
* @see app/Http/Controllers/Web/LeadDocumentController.php:55
* @route '/lead-documents/{document}'
*/
destroyForm.delete = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::download
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/download'
*/
export const download = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/lead-documents/{document}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::download
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/download'
*/
download.url = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

    if (Array.isArray(args)) {
        args = {
            document: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        document: args.document,
    }

    return download.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::download
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/download'
*/
download.get = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::download
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/download'
*/
download.head = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::download
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/download'
*/
const downloadForm = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::download
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/download'
*/
downloadForm.get = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::download
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/download'
*/
downloadForm.head = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

download.form = downloadForm

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::preview
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/preview'
*/
export const preview = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/lead-documents/{document}/preview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::preview
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/preview'
*/
preview.url = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

    if (Array.isArray(args)) {
        args = {
            document: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        document: args.document,
    }

    return preview.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::preview
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/preview'
*/
preview.get = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::preview
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/preview'
*/
preview.head = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::preview
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/preview'
*/
const previewForm = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::preview
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/preview'
*/
previewForm.get = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Web\LeadDocumentController::preview
* @see app/Http/Controllers/Web/LeadDocumentController.php:0
* @route '/lead-documents/{document}/preview'
*/
previewForm.head = (args: { document: string | number } | [document: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

preview.form = previewForm

const LeadDocumentController = { index, create, store, show, edit, update, destroy, download, preview }

export default LeadDocumentController